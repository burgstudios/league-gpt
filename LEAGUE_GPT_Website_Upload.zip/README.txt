LEAGUE GPT — Browser edition

To play on iPad:
1. In Safari, open https://app.netlify.com/drop
2. Choose this ZIP file for upload.
3. Open the new https://...netlify.app website link Netlify gives you.
4. Tap SKIP INTRO, then START 1V1, then AUTO DRIVE.

IMPORTANT: This is only a demonstration. Owner credits/items and gifts are NOT tied to secure accounts. Everyone who opens the demo will see the demo Owner features. For private owner accounts and real gifting, a server-backed login is required.
